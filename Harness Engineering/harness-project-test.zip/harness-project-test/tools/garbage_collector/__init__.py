"""Ferramentas de inspeção."""

