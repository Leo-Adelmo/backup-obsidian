"""Casos de uso."""

