# Mapa da arquitetura

```text
src/
├── domain/       # regras de negócio
├── application/  # casos de uso
└── adapter/      # integrações externas

tools/garbage_collector/  # inspeção do repositório
```

Direção permitida: `adapter -> application -> domain`.

O domínio não depende de adaptadores, ferramentas ou infraestrutura. O Garbage Collector detecta e classifica desvios; alterações destrutivas exigem etapa explícita e revisável.

