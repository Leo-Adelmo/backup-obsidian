# ExecPlans

Planos vivos para mudanças complexas. Consulte `PLANS.md` na raiz para o formato.

- `active/` — elaboração ou execução;
- `completed/` — histórico preservado.

