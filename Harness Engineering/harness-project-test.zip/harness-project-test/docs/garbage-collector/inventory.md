# Inventário

| ID | Regra | Severidade | Frequência | Ação |
|---|---|---|---|---|
| GC-001 | Entradas e links do harness existem | S2 | semanal | atualizar índice |
| GC-002 | ExecPlans ativos têm status e atualização | S2 | semanal | atualizar ou concluir |
| GC-003 | Imports respeitam arquitetura | S1 | PR | corrigir ou registrar decisão |
| GC-004 | Dependências declaradas são usadas | S2 | semanal | remover ou justificar |
| GC-005 | Exceções têm dono e prazo | S1 | semanal | revisar ou revogar |
| GC-006 | Sensores detectam fixtures sintéticas | S1 | PR | corrigir o sensor |

