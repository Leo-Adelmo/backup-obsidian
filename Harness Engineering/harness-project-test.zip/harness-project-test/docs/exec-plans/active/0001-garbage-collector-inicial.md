---
status: draft
created: 2026-07-24
---

# Garbage Collector inicial

## Objetivo

Construir um ciclo automatizado para detectar, classificar e priorizar a entropia do repositório.

## Escopo

Inclui scanner determinístico, relatório, severidade e encaminhamento para ExecPlans. Exclui exclusão automática e refatoração sem revisão.

## Etapas

1. Definir inventário e padrões.
2. Implementar scan somente leitura.
3. Gerar relatório com evidências.
4. Integrar sensores ao CI.
5. Criar baseline e revisar falsos positivos.

## Aceitação

- toda ocorrência tem evidência reproduzível;
- o relatório distingue nova, conhecida, resolvida e aceita;
- o scanner não modifica arquivos;
- alertas S1 geram ou referenciam um ExecPlan.

