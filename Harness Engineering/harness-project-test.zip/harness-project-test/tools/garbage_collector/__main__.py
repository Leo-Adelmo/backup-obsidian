from pathlib import Path


def main() -> int:
    root = Path(__file__).resolve().parents[2]
    required = ["AGENTS.md", "ARCHITECTURE.md", "PLANS.md", "docs"]
    missing = [path for path in required if not (root / path).exists()]
    for path in missing:
        print(f"GC-001 S1 missing-entry-point path={path}")
    if not missing:
        print("Garbage Collector: baseline estrutural aprovado")
    return int(bool(missing))


if __name__ == "__main__":
    raise SystemExit(main())

