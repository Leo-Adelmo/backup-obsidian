# Relatórios

Registre versão analisada, comandos, regras executadas, ocorrências por severidade, alertas novos/resolvidos/recorrentes/aceitos, limitações e ExecPlans relacionados.

