# Design docs

Propostas de design antes de uma decisão ser incorporada à arquitetura.

