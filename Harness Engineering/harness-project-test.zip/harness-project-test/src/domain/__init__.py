"""Regras de domínio."""

