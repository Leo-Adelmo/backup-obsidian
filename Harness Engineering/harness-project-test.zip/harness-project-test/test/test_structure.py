from pathlib import Path


ROOT = Path(__file__).parents[1]


def test_harness_entry_points_exist() -> None:
    expected = ["AGENTS.md", "ARCHITECTURE.md", "PLANS.md", "docs", "src", "tools"]
    assert all((ROOT / path).exists() for path in expected)


def test_garbage_collector_documents_exist() -> None:
    path = ROOT / "docs" / "garbage-collector"
    assert all((path / name).exists() for name in ["README.md", "inventory.md", "exceptions.md"])

