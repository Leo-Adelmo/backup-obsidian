# Padrão para ExecPlans

`PLANS.md` define o formato dos planos; não é um plano específico e não substitui o modo `/plan` do Codex.

Crie um ExecPlan para mudanças que atravessem componentes, alterem contratos, exijam investigação ou possam durar mais de uma sessão.

- novos: `docs/exec-plans/active/`;
- concluídos: `docs/exec-plans/completed/`;
- nome: `NNNN-descricao-curta.md`;
- preserve o histórico dos planos concluídos.

Todo plano deve conter status, objetivo, contexto, escopo, arquivos afetados, decisões, etapas com validação, critérios de aceitação, riscos, rollback e registro de progresso.

