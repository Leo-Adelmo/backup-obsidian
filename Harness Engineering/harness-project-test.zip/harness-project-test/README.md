# Harness Project Test

Projeto experimental para testar uma estrutura de Harness Engineering aplicada a um agente de programação.

## Objetivos

- manter o contexto do agente navegável e progressivo;
- separar orientação (`guides`) de verificação (`sensors`);
- impor limites arquiteturais por meio de regras automatizadas;
- registrar mudanças complexas em ExecPlans;
- tratar a manutenção contínua como um processo de Garbage Collector.

## Ponto de entrada

Comece por [`AGENTS.md`](AGENTS.md). Depois consulte [`ARCHITECTURE.md`](ARCHITECTURE.md) e, conforme a tarefa, os documentos indicados em `docs/`.

## Comandos previstos

```bash
ruff check .
ruff format --check .
pytest -q
python -m tools.garbage_collector scan
```

