# Instruções do projeto

Este arquivo é o índice de entrada. Mantenha-o curto e consulte a documentação específica conforme a tarefa.

## Fluxo

1. Leia `ARCHITECTURE.md`.
2. Consulte `docs/` para contexto específico.
3. Para mudanças complexas, siga `PLANS.md` e crie um ExecPlan em `docs/exec-plans/active/`.
4. Execute `ruff check .`, `ruff format --check .`, `pytest -q` e `python -m tools.garbage_collector scan`.

## Regras

- Não introduza dependências que violem `ARCHITECTURE.md`.
- Prefira tipos e contratos explícitos.
- Não silencie falhas dos sensores.
- O Garbage Collector é somente leitura por padrão; não exclua arquivos automaticamente.
- Toda descoberta relevante deve resultar em correção, exceção documentada ou ExecPlan.

## Índice

- `docs/quality/` — sensores e fitness functions.
- `docs/garbage-collector/` — política, inventário, exceções e relatórios.
- `docs/exec-plans/` — planos ativos e concluídos.

