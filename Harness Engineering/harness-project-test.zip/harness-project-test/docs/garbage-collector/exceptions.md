# Exceções temporárias

| ID | Regra | Motivo | Dono | Revisar em | ExecPlan |
|---|---|---|---|---|---|
| — | — | Nenhuma exceção registrada. | — | — | — |

