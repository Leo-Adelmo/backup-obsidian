"""Integrações externas."""

