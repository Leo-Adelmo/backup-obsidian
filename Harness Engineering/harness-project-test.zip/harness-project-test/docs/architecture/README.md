# Arquitetura detalhada

Decisões e explicações que não cabem no mapa curto de `ARCHITECTURE.md`.

