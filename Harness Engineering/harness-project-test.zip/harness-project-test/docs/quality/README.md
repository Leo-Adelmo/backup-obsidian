# Qualidade e sensores

- pré-commit: formatação, lint e testes rápidos;
- CI: testes completos, tipos, cobertura e arquitetura;
- periódico: Garbage Collector, dependências, documentação e mutação;
- inferencial: revisão semântica quando regras determinísticas forem insuficientes.

Fitness functions iniciais: direção de imports, adaptadores explícitos, logs estruturados, planos atualizados e exceções com prazo.

