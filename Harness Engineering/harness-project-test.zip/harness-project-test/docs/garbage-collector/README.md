# Garbage Collector

Processo contínuo para detectar e reduzir entropia em código, documentação, dependências, testes e no próprio harness. Não é exclusão indiscriminada: cada alerta produz evidência e uma decisão revisável.

```text
scan -> classify -> prioritize -> plan -> fix -> validate -> close/accept
```

## Categorias

Código morto, duplicação, dependências, arquitetura, testes, documentação, harness, ExecPlans e operação.

## Severidade

- S0: bloqueante;
- S1: alta, incluindo violação arquitetural ou sensor crítico ausente;
- S2: média, como duplicação ou documentação obsoleta;
- S3: baixa, como simplificação local.

## Regras

- `scan` é somente leitura;
- nenhuma exclusão automática no fluxo padrão;
- alerta contém caminho, regra, evidência, severidade e próxima ação;
- exceção possui dono e data de revisão;
- falhas recorrentes geram melhoria em guide, sensor ou arquitetura;
- relatório vazio não prova cobertura adequada do Garbage Collector.

## Cadência

Sensores rápidos a cada alteração; arquitetura no pull request; scan incremental diário; triagem semanal; revisão completa mensal.

